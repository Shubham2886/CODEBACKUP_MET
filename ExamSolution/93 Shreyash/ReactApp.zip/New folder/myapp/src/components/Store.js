import React, { useEffect, useState } from 'react'

export default function Store() {
    const [api, updateApi] = useState([])
    const [category, updateCategory] = useState([])

    useEffect(() => {
        fetch('https://fakestoreapi.com/products')
            .then(res => res.json())
            .then(val => {
                console.log(val)
                updateApi(val)
                console.log(val);
        fetch('https://fakestoreapi.com/products/categories')
                    .then(res => res.json())
                    .then(json => {
                        console.log(json)
                        updateCategory(json)
                        console.log(category, "Category");
                    })
            })
    }, [])

    return (
        <div>
            <h1>Store</h1>
            <hr/>
            
            <div className='container row'>
                <div class="col-xl-3">
                    <ul >
                        {
                            category.map((obj) =>
                                <li>{obj}</li>
                            )
                        }
                    </ul>
                </div>
                <div className='row col-xl-9'>

                    {
                        api && api.length > 0 && api.map(val =>
                            <div className='col-xl-3'>
                                <img src={val.image} className='img-fluid' />
                                <h2>{val.price}</h2>
                                <p>{val.title}</p>
                            </div>
                        )
                    }
                </div>

            </div>

        </div>
    )
}
